import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nuevo-estudiante',
  templateUrl: './nuevo-estudiante.component.html',
  styleUrls: []
})
export class NuevoEstudianteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
