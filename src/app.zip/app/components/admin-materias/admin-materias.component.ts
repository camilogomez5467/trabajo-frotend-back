import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-materias',
  templateUrl: './admin-materias.component.html',
  styleUrls: []
})
export class AdminMateriasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
