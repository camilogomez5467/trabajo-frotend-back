export class InformeInput {
  idInforme: number
  idEstudiante: number
}
