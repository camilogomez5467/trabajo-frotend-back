export class EstudianteInput {
  idEstudiante: number
}
