export interface Evaluacion {
  idEvaluacion: number
  nombre: string
  tipo: string
  fecha: Date
  idMateria: number
  nombreMateria: string
}
