export interface Estudiante {
  idEstudiante: number
  nombre: string
  apellido: string
  documento: string
  email: string
  telefono: string
  fechaNacimiento: string
  direccion: string
}
