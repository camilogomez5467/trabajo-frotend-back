export class GrupoInput {
  idGrupo: number
}
