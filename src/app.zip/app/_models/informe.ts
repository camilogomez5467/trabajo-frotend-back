export interface Informe {
  idInforme: number
  titulo: string
  tipo: string
  fechaGeneracion: Date
  descripcion: string
}
