export class MateriaInput {
  idMateria: number;
}
