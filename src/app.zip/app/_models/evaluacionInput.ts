export class EvaluacionInput {
  idEvaluacion: number
  idEstudiante: number
  idMateria: number
}
