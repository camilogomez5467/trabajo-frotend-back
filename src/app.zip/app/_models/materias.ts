export interface Materia {
  idMateria: number;
  nombre: string;
}
