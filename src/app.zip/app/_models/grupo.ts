export interface Grupo {
  idGrupo: number
  nombre: string
  grado: string
  numeroEstudiantes: number
}
