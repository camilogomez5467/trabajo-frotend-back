export interface MenuItem {
  id: number
  nombre: string
  ruta: string
  icono: string
  activo: boolean
}
